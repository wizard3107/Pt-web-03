import './App.css';
function App() {
  return (
    <div className="App">
      <div>
        <h1>Mobile Operating System</h1>
        <ul>
          <li>Android</li>
          <li>Blackberry</li>
          <li>iPhone</li>
          <li>Windows Phone</li>
        </ul>
      </div>
      <div>
        <h1>Mobile Manufactures</h1>
        <ul>
          <li className='square'>Samsung</li>
          <li className='square'>HTC</li>
          <li>Micromax</li>
          <li className='empty'>Apple</li>
        </ul>
      </div>

    </div>
  );
}

export default App;
